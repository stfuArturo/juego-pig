import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Juego del Pig'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _diceValue = 1;
  int _playerScore = 0;
  int _computerScore = 0;
  int _tempScore = 0;
  bool _isPlayerActive = true;
  final Random _random = Random();

  void _rollDice() {
    setState(() {
      _diceValue = _random.nextInt(6) + 1;
      if (_diceValue == 1) {
        _showPigAlert();
        _tempScore = 0;
        _isPlayerActive = !_isPlayerActive;
        _computerTurn();
      } else {
        _tempScore += _diceValue;
      }
    });
  }

  void _fixScore() {
    setState(() {
      if (_isPlayerActive) {
        _playerScore += _tempScore;
      } else {
        _computerScore += _tempScore;
      }
      _tempScore = 0;
      _isPlayerActive = false;
      _computerTurn();

      if (_playerScore >= 100 || _computerScore >= 100) {
        _showWinnerAlert();
      }
    });
  }

  void _showPigAlert() {
    String loser = _isPlayerActive ? 'Humano' : 'Computadora';
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('¡Pig! 🐷'),
          content: Text('$loser sacó un 1. Perdió los puntos temporales.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }

  void _showWinnerAlert() {
    String winner = _playerScore >= 100 ? 'Humano' : 'Computadora';
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('¡Felicidades! 🎉'),
          content: Text('$winner ganó el juego.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _resetGame();
              },
              child: Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }

  void _computerTurn() {
    if (!_isPlayerActive) {
      Future.delayed(Duration(seconds: 1), () {
        _rollDice();
        if (_tempScore >= 20 && _tempScore <= 26) {
          _fixScore();
          _isPlayerActive = true;
        } else if (_tempScore < 20) {
          _computerTurn();
        }

        if (_playerScore >= 100 || _computerScore >= 100) {
          _showWinnerAlert();
        }
      });
    }
  }

  void _resetGame() {
    setState(() {
      _diceValue = 1;
      _playerScore = 0;
      _computerScore = 0;
      _tempScore = 0;
      _isPlayerActive = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  'Humano: $_playerScore',
                  style: TextStyle(fontSize: 20, color: _isPlayerActive ? Colors.green : Colors.red),
                ),
                Text(
                  'Computadora: $_computerScore',
                  style: TextStyle(fontSize: 20, color: !_isPlayerActive ? Colors.green : Colors.red),
                ),
              ],
            ),
            SizedBox(height: 10),
            Text(
              'Puntaje Temporal: $_tempScore',
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            Dice(value: _diceValue),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: _rollDice,
                  child: Text('Lanzar Dado'),
                ),
                ElevatedButton(
                  onPressed: _isPlayerActive ? _fixScore : null,
                  child: Text('Fijar Puntos'),
                ),
                ElevatedButton(
                  onPressed: _resetGame,
                  child: Text('Reiniciar Juego'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class Dice extends StatelessWidget {
  final int value;

  const Dice({Key? key, required this.value}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<Widget> circles = [];
    for (int i = 0; i < value; i++) {
      circles.add(
        Container(
          width: 20,
          height: 20,
          margin: EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: Colors.black,
            shape: BoxShape.circle,
          ),
        ),
      );
    }

    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.red, width: 2),
      ),
      child: Center(
        child: Wrap(
          alignment: WrapAlignment.center,
          children: circles,
        ),
      ),
    );
  }
}
